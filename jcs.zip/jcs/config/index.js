// 开发

window.apiBase = '/apiLoginSystem' //系统权限

window.fileimg = '/apiLoginSystem/file/uploadFiles' //上传照片

window.filemp3 = '/apiLoginSystem/file/mp3' //上传mp3